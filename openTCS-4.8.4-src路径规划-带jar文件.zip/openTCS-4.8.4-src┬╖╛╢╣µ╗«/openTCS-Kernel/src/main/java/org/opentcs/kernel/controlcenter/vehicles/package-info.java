/**
 * Classes of the kernel control center concerning vehicles/vehicle drivers.
 * The GUI parts of the driver framework.
 */
package org.opentcs.kernel.controlcenter.vehicles;
