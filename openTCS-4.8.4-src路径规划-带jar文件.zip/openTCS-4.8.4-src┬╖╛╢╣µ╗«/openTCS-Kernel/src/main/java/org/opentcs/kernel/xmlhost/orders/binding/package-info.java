/**
 * XML binding classes for creating transport orders via a plain XML/TCP
 * interface.
 */
package org.opentcs.kernel.xmlhost.orders.binding;
