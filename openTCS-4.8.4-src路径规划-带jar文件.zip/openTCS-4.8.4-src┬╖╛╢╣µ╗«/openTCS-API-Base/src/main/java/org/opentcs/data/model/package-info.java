/**
 * Classes for maintaining the (mainly static) structure and content of openTCS
 * course layouts and the attributes and state of vehicles.
 */
package org.opentcs.data.model;
