/**
 * Classes describing the visual attributes of a model.
 */
package org.opentcs.data.model.visualization;
