/**
 * Kernel query definitions and supporting annotations as well as convenience
 * methods.
 */
package org.opentcs.access.queries;
