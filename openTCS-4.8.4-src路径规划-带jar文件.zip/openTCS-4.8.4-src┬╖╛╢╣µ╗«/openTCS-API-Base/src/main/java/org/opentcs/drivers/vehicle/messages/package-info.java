/**
 * Reference implementations of commonly used messages to be processed by vehicle drivers.
 */
package org.opentcs.drivers.vehicle.messages;
