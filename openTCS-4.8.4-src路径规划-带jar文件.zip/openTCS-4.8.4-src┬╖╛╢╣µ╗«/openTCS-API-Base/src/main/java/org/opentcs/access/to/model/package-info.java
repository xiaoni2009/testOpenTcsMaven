/**
 * Transfer object classes for plant model objects.
 */
package org.opentcs.access.to.model;
