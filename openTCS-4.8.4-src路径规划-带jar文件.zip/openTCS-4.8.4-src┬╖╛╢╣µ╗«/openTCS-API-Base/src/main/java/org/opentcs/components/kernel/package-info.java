/**
 * Interfaces for pluggable strategies and other components for a kernel application.
 */
package org.opentcs.components.kernel;
