/**
 * Components needed for controlling physical vehicles and processing information sent by them.
 */
package org.opentcs.drivers.vehicle;
