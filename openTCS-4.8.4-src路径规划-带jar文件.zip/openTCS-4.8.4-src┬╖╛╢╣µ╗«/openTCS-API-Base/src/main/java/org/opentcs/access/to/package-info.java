/**
 * Transfer object classes for domain objects.
 */
package org.opentcs.access.to;
