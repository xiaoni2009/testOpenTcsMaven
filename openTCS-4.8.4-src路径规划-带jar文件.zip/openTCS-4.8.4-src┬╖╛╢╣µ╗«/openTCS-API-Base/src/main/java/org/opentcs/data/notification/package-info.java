/**
 * Classes for storing user-targeted notifications.
 */
package org.opentcs.data.notification;
