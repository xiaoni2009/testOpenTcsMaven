/**
 * Classes utilized for extending and customizing openTCS applications.
 */
package org.opentcs.customizations;
