/**
 * Classes for emulating the behaviour of a physical vehicle.
 */
package org.opentcs.virtualvehicle;
