/**
 * Utility classes collecting statistical data.
 */
package org.opentcs.util.statistics;
